package player.util;

public enum ItemType{
    CANE, 
    SLIPPERS, 
    HAND_BAG,
}