package progress.upgrades.util;
import player.Granny;

public interface Purchasable{
    public boolean isAffordable(Granny granny);
}