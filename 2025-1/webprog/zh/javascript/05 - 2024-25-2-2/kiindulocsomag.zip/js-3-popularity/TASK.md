[] a. (3) Oszlop
[] b. (1) Oszlop színe
[] c. (2) Oszlop felirata
[] d. (3) Körcikk
[] e. (1) Körcikk színe