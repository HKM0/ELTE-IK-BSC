[] a. (1) 2000 előtti
[] b. (2) 100 millió
[] c. (2) Love
[] d. (3) 2024 átlag
[] e. (2) Zenecím számjegy