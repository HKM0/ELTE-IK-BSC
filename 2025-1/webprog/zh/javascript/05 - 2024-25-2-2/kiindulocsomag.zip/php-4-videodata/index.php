<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>4. feladat</title>
    <link rel="stylesheet" href="index.css" />
</head>

<body>
    <h1>4. Videók</h1>
    <div id="main">
        <a class="card very-popular" href="https://www.youtube.com/watch?v=WXwgZL4zx9o" target="_blank">
            <img src="img/0573ddf4.jpg">
            <h2>Alexander Rybak - Fairytale</h2>
            <span class="year">2009</span>
            <span class="views">105 millió</span>
        </a>
        <a class="card partially-popular" href="https://www.youtube.com/watch?v=p6e1TmYb33w" target="_blank">
            <img src="img/31fb4561.jpg">
            <h2>AWS - Viszlát Nyár</h2>
            <span class="year">2018</span>
            <span class="views">2.6 millió</span>
        </a>
        <a class="card slightly-popular" href="https://www.youtube.com/watch?v=l6rS8Dv5g-8" target="_blank">
            <img src="img/d2fa5d22.jpg">
            <h2>Käärijä - Cha Cha Cha</h2>
            <span class="year">2023</span>
            <span class="views">44 millió</span>
        </a>
    </div>
</body>

</html>