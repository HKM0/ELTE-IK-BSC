[] a. (2) a.card
[] b. (1) h2
[] c. (1) year, views
[] d. (2) img
[] e. (2) popular
[] f. (2) sort