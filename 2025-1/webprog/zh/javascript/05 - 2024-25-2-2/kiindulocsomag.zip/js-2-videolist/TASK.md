[] a. (2) Listázás
[] b. (2) Kijelölés
[] c. (1) Össz nézettség
[] d. (2) Kijelölt össz
[] e. (4) Add, sub
[] f. (4) Fejléces rendezés