[] a. (3) Bal-jobb oszlop
[] b. (2) Új kapcsolat
[] c. (3) Törlés
[] d. (2) Legördülő szűrés
[] e. (2) Rendezés