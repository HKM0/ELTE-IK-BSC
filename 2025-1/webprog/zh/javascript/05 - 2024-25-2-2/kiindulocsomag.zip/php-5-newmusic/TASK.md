[] a. (2) Kötelező
[] b. (1) Cím min 5
[] c. (1) Cím kötőjel
[] d. (1) Év egész szám
[] e. (1) Nézettség szám
[] f. (1) KéziID yes/no
[] g. (1) ID feltételesen kötelező
[] h. (1) ID nem létezik
[] i. (2) ID tartalma
[] j. (2) Állapottartás
[] k. (1) Success/errors