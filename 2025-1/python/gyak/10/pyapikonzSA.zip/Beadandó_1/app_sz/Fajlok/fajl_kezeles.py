import json

class KurzusFajlKezelo:
    utvonal = "kurzusok.json"

    def kurzusok_olvasas(self):
        pass

    def kurzusok_iras(self, kurzusok):
        pass
